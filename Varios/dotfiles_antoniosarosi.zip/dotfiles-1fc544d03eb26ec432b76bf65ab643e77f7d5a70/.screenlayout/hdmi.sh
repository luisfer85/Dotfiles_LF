xrandr | grep ' connected' | grep 'HDMI' | awk '{print $1}'
