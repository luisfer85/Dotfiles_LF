# Spectrwm Config

Include this directory in your **$HOME**, otherwise the baraction and autostart
scripts will not work.
Check the software listed [here](https://github.com/antoniosarosi/dotfiles#Software),
keybindings are based on it.

Also, check [this directory](https://github.com/antoniosarosi/dotfiles/tree/master/.theme)
if you want to change the theme of all your programs on startup or on window
manager restart.

![Spectrwm](.screenshot.png)
