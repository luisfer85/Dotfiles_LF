#!/bin/bash

echo -n `checkupdates | wc -l`
