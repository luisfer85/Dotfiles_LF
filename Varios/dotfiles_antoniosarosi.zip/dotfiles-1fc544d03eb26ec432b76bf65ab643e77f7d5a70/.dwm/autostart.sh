#!/bin/bash

dwmblocks &
