Use **set-themes.py** script to set up all your themes on login or when
restarting wm. That python script can be called from all your window manager
autoload scripts. Just make sure to set up **theme.json** correctly.
